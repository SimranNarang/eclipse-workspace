### Problem Statement

In this Assignment 3, we will

    1. Read the header.  
    2. Identify the Data type of each field 